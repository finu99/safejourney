package com.example.safejourney;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Custom_students extends BaseAdapter {
    String[] student_id,student_name,student_image,student_housename,student_place,student_post,student_PIN,DOB,gender,email,student_lid,class_id,parent_id,routepoint_id;
    private Context context;

    public Custom_students(Context appcontext, String[]student_id, String[]student_name, String[]student_image,String[]student_housename,String[]student_place,String[]student_post,String[]student_PIN,String[]DOB,String[]gender,String[]email,String[]student_lid,String[]class_id,String[]parent_id,String[]routepoint_id)
    {
        this.context=appcontext;
        this.student_id=student_id;
        this.student_name=student_name;
        this.student_image=student_image;
        this.student_housename=student_housename;
        this.student_place=student_place;
        this.student_post=student_post;
        this.student_PIN=student_PIN;
        this.DOB=DOB;
        this.gender=gender;
        this.email=email;
        this.student_lid=student_lid;
        this.class_id=class_id;
        this.parent_id=parent_id;
        this.routepoint_id=routepoint_id;




    }

    @Override
    public int getCount() {
        return routepoint_id.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.customviewstudent,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView tvname=(TextView)gridView.findViewById(R.id.textView4);
        TextView tvhouse=(TextView)gridView.findViewById(R.id.textView5);
        TextView tvplace=(TextView)gridView.findViewById(R.id.textView6);
        ImageView img=(ImageView) gridView.findViewById(R.id.imageView2);
        Button bt6=(Button) gridView.findViewById(R.id.button6);
        Button bt=(Button) gridView.findViewById(R.id.button);

        bt6.setTag(student_lid[i]);
        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String lid= view.getTag().toString();
                SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("stlid",lid);
                ed.commit();

                Intent ins= new Intent(context,Entryleave.class);
                ins.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ins);

            }
        });

        bt.setTag(parent_id[i]);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String lid= view.getTag().toString();
                SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("toid",lid);
                ed.commit();

                Intent ins= new Intent(context,Test.class);
                ins.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ins);
            }
        });


        tvname.setText(student_name[i]);
        tvhouse.setText(student_housename[i]);
        tvplace.setText(student_place[i]);


        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
        String ip=sh.getString("ip","");

        String url="http://" + ip + ":5000/"+student_image[i];


        Picasso.with(context).load(url). into(img);

        return gridView;
    }
}
