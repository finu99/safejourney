package com.example.safejourney;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Custom_viewentry extends BaseAdapter {
    String[]entryleave_id,checkin,checkout,date;

    private Context context;

    public Custom_viewentry(Context appcontext, String[]entryleave_id, String[]checkin,String[]checkout,String[]date)
    {
        this.context=appcontext;
        this.entryleave_id=entryleave_id;
        this.checkin=checkin;
        this.checkout=checkout;
        this.date=date;





    }

    @Override
    public int getCount() {
        return checkout.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.custom_entryleave,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView tvdate=(TextView)gridView.findViewById(R.id.textView7);
        TextView tvcheckin=(TextView)gridView.findViewById(R.id.textView8);
        TextView tvcheckout=(TextView)gridView.findViewById(R.id.textView9);


        tvdate.setText(date[i]);
        tvcheckin.setText(checkin[i]);
        tvcheckout.setText(checkout[i]);


        return gridView;
    }
}
