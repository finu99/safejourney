package com.example.safejourney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ShareActionProvider;

public class ipset extends AppCompatActivity implements View.OnClickListener {
EditText ed1;
    Button bt;

    @Override
    public void onBackPressed() {
        Intent ins= new Intent(Intent.ACTION_MAIN);
        ins.addCategory(Intent.CATEGORY_HOME);
        ins.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(ins);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ipset);
        ed1=(EditText) findViewById(R.id.atvEmailLog);
        bt=(Button) findViewById(R.id.btnSignIn);
        bt.setOnClickListener(this);
        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ed1.setText(sh.getString("ip",""));
    }

    @Override
    public void onClick(View view) {

        if(ed1.getText().toString().length()>0) {
            SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            SharedPreferences.Editor ed = sh.edit();
            ed.putString("ip", ed1.getText().toString());
            ed.putString("url", "http://" + ed1.getText().toString() + ":5000/");
            ed.commit();

            Intent ij = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(ij);
        }
        else
        {
            ed1.setError("Missing");
        }

    }
}