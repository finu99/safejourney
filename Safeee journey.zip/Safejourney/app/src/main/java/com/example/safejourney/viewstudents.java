package com.example.safejourney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class viewstudents extends AppCompatActivity {
  ListView lv;

  String [] student_id,student_name,student_image,student_housename,student_place,student_post,student_PIN,DOB,gender,email,student_lid,class_id,parent_id,routepoint_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewstudents);
        lv=(ListView)findViewById(R.id.list);



        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        String hu = sh.getString("url", "");
        String url =  hu + "view_studententryleavedriver";



        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        // response
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            if (jsonObj.getString("status").equalsIgnoreCase("ok")) {

                                JSONArray js = jsonObj.getJSONArray("data");
                                student_id=new String[js.length()];
                                student_name=new String[js.length()];
                                student_image=new String[js.length()];
                                student_housename=new String[js.length()];
                                student_place=new String[js.length()];
                                student_post=new String[js.length()];
                                student_PIN=new String[js.length()];
                                DOB=new String[js.length()];
                                gender=new String[js.length()];
                                email=new String[js.length()];
                                student_lid=new String[js.length()];
                                class_id=new String[js.length()];
                                parent_id=new String[js.length()];
                                routepoint_id=new String[js.length()];

                                for(int i=0;i<js.length();i++) {

                                    JSONObject a= js.getJSONObject(i);
                                    student_id[i]=a.getString("student_id");
                                    student_name[i]=a.getString("student_name");
                                    student_image[i]=a.getString("student_image");
                                    student_housename[i]=a.getString("student_housename");
                                    student_place[i]=a.getString("student_place");
                                    student_post[i]=a.getString("student_post");
                                    student_PIN[i]=a.getString("student_PIN");
                                    DOB[i]=a.getString("DOB");
                                    gender[i]=a.getString("gender");
                                    email[i]=a.getString("email");
                                    student_lid[i]=a.getString("student_lid");
                                    class_id[i]=a.getString("class_id");
                                    parent_id[i]=a.getString("parent_id");
                                    routepoint_id[i]=a.getString("routepoint_id");

                                }

                                lv.setAdapter(new Custom_students(getApplicationContext(),student_id,student_name,student_image,student_housename,student_place,student_post,student_PIN,DOB,gender,email,student_lid,class_id,parent_id,routepoint_id));


                            }


                            // }
                            else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        }    catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();

                params.put("lid",sh.getString("lid",""));




                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS=100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);
    }
}
